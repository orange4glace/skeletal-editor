function Keyframe(time, x, y, l, a) {
	this.time = time;
	this.x = x;
	this.y = y;
	this.l = l;
	this.a = a;
}