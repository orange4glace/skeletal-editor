

var gl;

var canvas;

var boneManager;
var currentBone;
var currentParent = [];
var n_slider;
var c_slider;

var animations = [];
var animDivs = 0;
var currentFrame, currentAnimation;
var timer, cFrame;
var isRunning = false;

$(window).ready(function() {
	canvas = document.getElementById("lesson01-canvas");
	n_slider = new Slider("nb_s", 100, 15);
	n_slider.bind("nb_a", 360);
	c_slider = new Slider("cb_s", 100, 15);
	c_slider.bind("cb_a", 360);
	
	$("#nb_frp").prop("checked", true);
	$("#nb_fra").prop("checked", true);
	
	boneManager = new BoneManager();
	
	$(canvas).mousemove(function(e) {
		var pos = getMousePos(canvas, e);
		pt.push(vec3.create([pos.x, pos.y, 0]));
	});
	
	$("#btn_newBone").click(function() {
		addBone();
		refreshBoneList();
	});
	
	$(document).click(function() {
		return;
	});
	
	/*
	 * Anim
	 */
	$("#div_keyframes").scroll(function() {
		$("#div_keyframes_info").scrollLeft($(this).scrollLeft());
	});
	$("#div_keyframes_info").scroll(function() {
		$("#div_keyframes").scrollLeft($(this).scrollLeft());
	});
	
	$("#inp_frameCount").change(function() {
		changeFrameCount($(this).val());
	});
	
	$("#btn_newAnim").click(function() {
		addAnimation($("#inp_anim").val());
	});
	
	$("#btn_newKeyframe").click(function() {
		addKeyframe();
	});
	
	$("#btn_toggleAnim").click(function() {
		if (!isRunning) {
			$("#btn_toggleAnim").text("Stop Animation");
			startAnimation();
			isRunning = true;
		}
		else {
			$("#btn_toggleAnim").text("Start Animation");
			stopAnimation();
			isRunning = false;
		}
	});
	
	/*
	 * Save/Load
	 */
	$("#btn_save").click(function() {
		var s = "<bones>";
		for (var i in boneManager.bones) {
			var bone = boneManager.bones[i];
			var btf = new BoneToFile(bone);
			s += btf.s;
		}
		s += "</bones>";
		var blob = new Blob([s], {type: "text/xml"});
		saveAs(blob, $("#inp_save").val() + ".xml");
	});
	
	$("#btn_load").click(function() {
		var bones = [];
		var xml = $($("#text_load").val());
		$(xml).find("bone").each(function() {
			var bone;
			var name = $(this).find("name").text();
			var x = $(this).find("x").text()*1;
			var y = $(this).find("y").text()*1;
			var l = $(this).find("l").text()*1;
			var a = $(this).find("a").text()*1;
			var flag = $(this).find("flag").text()*1;
			var parent = $(this).find("parent").text();
			bone = new Bone(x, y, l, a, flag, name, parent);
			$(this).find("animations").find("anim").each(function() {
				var animation;
				var aname = $(this).find("aname").text();
				var framecount = $(this).find("framecount").text();
				animation = new Animation(aname, framecount);
				$(this).find("keyframes").find("keyframe").each(function() {
					var keyframe;
					var time = $(this).find("time").text()*1;
					var kx = $(this).find("ax").text()*1;
					var ky = $(this).find("ay").text()*1;
					var kl = $(this).find("al").text()*1;
					var ka = $(this).find("aa").text()*1;
					keyframe = new Keyframe(time, kx , ky, kl, ka);
					animation.addKeyframe(keyframe);
				});
				bone.addAnimationObject(animation);
				addAnimation(animation.name, animation.framecount);
			});	
			bones.push(bone);
			boneManager.addBoneObject(bone);
		});
		
		for (var i in bones) {
			var parent = findBoneByName(bones[i].parent);
			if (parent) bones[i].parent = parent;
		}
		
		refreshBoneList();
	});

	
	$("#cb_x").change(function() { refreshCurrentBone(); });
	$("#cb_y").change(function() { refreshCurrentBone(); });
	$("#cb_l").change(function() { refreshCurrentBone(); });
	c_slider.change = function() { refreshCurrentBone(); };
	$("#cb_n").change(function() { refreshCurrentBone(); });
	$("#cb_frp").change(function() { refreshCurrentBone(); });
	$("#cb_fra").change(function() { refreshCurrentBone(); });
	$("#cb_p").change(function() { refreshCurrentBone(); });
	
});

/* GL THINGS */
function initGL(canvas) {
	try {
		gl = canvas.getContext("experimental-webgl");
		gl.viewportWidth = canvas.width;
		gl.viewportHeight = canvas.height;
	} catch (e) {
	}
	if (!gl) {
		alert("Could not initialise WebGL, sorry :-(");
	}
}


function getShader(gl, id) {
	var shaderScript = document.getElementById(id);
	if (!shaderScript) {
		return null;
	}

	var str = "";
	var k = shaderScript.firstChild;
	while (k) {
		if (k.nodeType == 3) {
			str += k.textContent;
		}
		k = k.nextSibling;
	}

	var shader;
	if (shaderScript.type == "x-shader/x-fragment") {
		shader = gl.createShader(gl.FRAGMENT_SHADER);
	} else if (shaderScript.type == "x-shader/x-vertex") {
		shader = gl.createShader(gl.VERTEX_SHADER);
	} else {
		return null;
	}

	gl.shaderSource(shader, str);
	gl.compileShader(shader);

	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
		alert(gl.getShaderInfoLog(shader));
		return null;
	}

	return shader;
}


var shaderProgram;

function initShaders() {
	var fragmentShader = getShader(gl, "shader-fs");
	var vertexShader = getShader(gl, "shader-vs");

	shaderProgram = gl.createProgram();
	gl.attachShader(shaderProgram, vertexShader);
	gl.attachShader(shaderProgram, fragmentShader);
	gl.linkProgram(shaderProgram);

	if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
		alert("Could not initialise shaders");
	}

	gl.useProgram(shaderProgram);

	shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
	gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

	shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
	shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
	shaderProgram.colorVec = gl.getUniformLocation(shaderProgram, "colorVec");
}


var mvMatrix = mat4.create();
var pMatrix = mat4.create();
var color = vec3.create();

function setMatrixUniforms() {
	gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, pMatrix);
	gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
	gl.uniform4f(shaderProgram.colorVec, color[0], color[1], color[2], 1.0);
}


function drawScene() {
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
	
	for (var i = 0; i < boneManager.bones.length; i ++) {
		boneManager.bones[i].draw();
	}
}



function webGLStart() {
	var canvas = document.getElementById("lesson01-canvas");
	initGL(canvas);
	initShaders();

	gl.clearColor(0.0, 0.0, 0.0, 1.0);
	gl.enable(gl.DEPTH_TEST);

	gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
	mat4.ortho(0, 800, 600, 0, -1, 1, pMatrix);
	mat4.identity(mvMatrix);
	tick();
}

function tick() {
	requestAnimFrame(tick);
	drawScene();
}
/*
 * End of GL Things
 */	
 
/*
 * Essential
 */
function getMousePos(canvas, evt) {
	var rect = canvas.getBoundingClientRect();
	return {
	x: evt.clientX - rect.left,
	y: evt.clientY - rect.top
	};
}

function refreshBoneList() {
	var d = document.getElementById("if_bones");
	for (var i in boneManager.bones) {
		var bone = boneManager.bones[i];
		var s = document.getElementById("s_" + bone.name);
		if (s) continue;
		s = document.createElement("span");
		$(s).attr("id", "s_" + bone.name);
		$(s).attr("name", bone.name);
		var t = document.createTextNode(" [" + bone.name + "] ");
		s.appendChild(t);
		d.appendChild(s);
		$(s).bind("click", retrieve_selectBone($(s).attr("name")));
	}
}

function retrieve_selectBone(name) {
	return function() { selectBone(name); };
}

function addBone() {
	if (findBoneByName($("#nb_n").val())) return;
	var parent = findBoneByName($("#nb_p").val());
	var flag = 0;
	if ($("#nb_frp").is(":checked")) flag = flag | 1;
	if ($("#nb_fra").is(":checked")) flag = flag | 2;
	boneManager.addBone($("#nb_x").val() * 1, $("#nb_y").val() * 1, $("#nb_l").val() * 1, $("#nb_a").val() * 1, flag, $("#nb_n").val(), parent);
	
	$("#nb_x").val("0");
	$("#nb_y").val("0");
	$("#nb_l").val("0");
	$("#nb_n").val("");
	$("#nb_p").val("");
}

function selectBone(name) {
	for (var i in boneManager.bones) {
		var os = document.getElementById("s_" + boneManager.bones[i].name);
		$(os).css("color", "black");
		$(os).css("font-weight", "normal");
	}
	var s = document.getElementById("s_" + name);
	$(s).css("color", "red");
	$(s).css("font-weight", "bold");
	var b = findBoneByName(name);
	var p = b.parent;
	currentParent = [];
	while(p) {
		currentParent.push(p);
		p = p.parent;
	}
	currentBone = b;
	$("#cb_x").val(currentBone.x);
	$("#cb_y").val(currentBone.y);
	$("#cb_l").val(currentBone.l);
	$("#cb_a").val(currentBone.a);
	$("#cb_n").val(currentBone.name);
	if (currentBone.parent)
		$("#cb_p").val(currentBone.parent.name);
	else
		$("#cb_p").val("");
	if (currentBone.parent)
		$("#cb_p").val(currentBone.parent.name);
	if ((currentBone.flag & 1) == 1) $("#cb_frp").prop("checked", true);
	else $("#cb_frp").prop("checked", false);
	if ((currentBone.flag & 2) == 2) $("#cb_fra").prop("checked", true);
	else $("#cb_fra").prop("checked", false);
}

function findBoneByName(name) {
	var bone;
	for (var i in boneManager.bones)
		if (boneManager.bones[i].name == name) { bone = boneManager.bones[i]; break; }
	return bone;
}

function refreshCurrentBone() {
	if (currentBone) {
		currentBone.x = $("#cb_x").val() * 1;
		currentBone.y = $("#cb_y").val() * 1;
		currentBone.l = $("#cb_l").val() * 1;
		currentBone.a = $("#cb_a").val() * 1;
		currentBone.flag = (($("#cb_frp").is(":checked") ? 1 : 0) | ($("#cb_fra").is(":checked") ? 2 : 0));
		if (currentBone.name != $("#cb_n").val()) {
			var n = $("#cb_n").val();
			for (var i in boneManager.bones)
				if (boneManager.bones[i].name == n) { 
					alert("Same name exists!");
					$("#cb_n").val(currentBone.name);
					return; 
				}
			var s = document.getElementById("s_" + currentBone.name);
			$(s).text(" [" + n + "] ");
			$(s).attr("id", "s_" + n);
			$(s).attr("name", n);
			currentBone.name = $("#cb_n").val();
		}
		if ($("#cb_p").val() == "") {
			currentBone.parent = null;
		}
		else if ($("#cb_p").val() == currentBone.name) {
			$("#cb_p").val((currentBone.parent ? currentBone.parent.name : ""));
			alert ("Parent cannot be same with child!");
			return;
		}
		else {
			var n = $("#cb_p").val();
			var parent = findBoneByName(n);
			if (!parent) {
				$("#cb_p").val((currentBone.parent ? currentBone.parent.name : ""));
				alert ("Parent doesn't exist!");
				return;
			}
			currentBone.parent = parent;
		}
	}
}

function setupAnimFrames(num) {

	var pdw = $("#p_frames");
	if (pdw) $(pdw).remove();
	
	var dw = document.createElement("p");
	$(dw).attr("id", "p_frames");
	var z = document.createElement("div");
	$(z).css({
		"width" : 60,
		"height" : 25,
		"display" : "inline-block"
	});
	$(dw).append(z);
	for (var i = 0; i < num; i ++) {
		var d = document.createElement("div");
		var t = document.createTextNode(i+1);
		$(d).css({
			"width" : 25,
			"height" : 25,
			"display" : "inline-block",
			"border" : "1px dashed gray",
			"font-size" : "8pt",
			"text-align" : "center"
		});
		$(d).attr("id", "div_frameInfo_" + i);
		$(d).append(t);
		$(dw).append(d);
	}
	$("#div_keyframes_info").prepend(dw);
}

function addAnimation(name, framecount) {

	if (getAnimByName(name)) return; 
	var anim = new AnimationInfo(name, (framecount ? framecount : 60) ,30);
	animations.push(anim);

	var p = document.createElement("p");
	var t = document.createTextNode(name);
	$(p).append(t);
	$("#div_animations").append(p);
	
	$(p).bind("click", function() { getAnimation(anim.name); });

}



function getAnimation(name) {

	currentAnimation = name;
	$("#div_keyframes").html("");
	var animInfo = getAnimByName(name);
	$("#inp_frameCount").val(animInfo.frameCount);

	setupAnimFrames(animInfo.frameCount);
	
	for (var i in boneManager.bones) {
		var bone = boneManager.bones[i];
		var anim = bone.getAnimationByName(animInfo.name);
		var dw = document.createElement("p");
		$(dw).css("width", animInfo.frameCount * 27 + 70);
		var z = document.createElement("div");
		var zt = document.createTextNode(bone.name);
		$(z).append(zt);
		$(z).css({
			"width" : 60,
			"height" : 25,
			"float" : "left"
		});
		$(dw).append(z);
		for (var i = 0; i < animInfo.frameCount; i ++) {
			var d = document.createElement("div");
			$(d).css({
				"width" : 25,
				"height" : 25,
				"border" : "1px solid black",
				"float" : "left"
			});
			$(d).attr({
				"anim" : animInfo.name,
				"bone" : bone.name,
				"time" : i
			});
			if (anim) if (anim.getKeyframe(i)) $(d).css("background-color", "blue");
			$(dw).append(d);
			$(d).bind("click", selectKeyframe(d));
		}
		$("#div_keyframes").append(dw);
	}
}

function selectKeyframe (d) {
	return function() {
		var hasFrame = false;
		if (currentFrame) {
			var f = $("#div_frameInfo_" + $(currentFrame).attr("time"));
			$(f).css("background-color", "white");
			var bone = findBoneByName($(currentFrame).attr("bone"));
			var anim = bone.getAnimationByName($(currentFrame).attr("anim"));
			if (anim) {
				var frame = anim.getKeyframe($(currentFrame).attr("time") * 1);
				if (frame) hasFrame = true;
			}
		}
		$(currentFrame).css("background-color", (hasFrame ? "blue" : "white"));
		currentFrame = d;
		$(currentFrame).css("background-color", "red");
		getKeyframe($(currentFrame).attr("anim"), $(currentFrame).attr("time")*1);
		selectBone($(currentFrame).attr("bone"));
	};
}

function getKeyframe(anim, time) {
	var f = $("#div_frameInfo_" + time);
	var f2 = $("#div_frameInfo_" + (time-1));
	if (f2) $(f2).css("background-color", "white");
	$(f).css("background-color", "green");
	for (var i in boneManager.bones) {
		var bone = boneManager.bones[i];
		var animation = bone.getAnimationByName(anim);
		if (!animation) continue;
		var status = animation.getKeyframeStatus(time);
		bone.set(status.x, status.y, status.l, status.a);
	}
}

function changeFrameCount(count) {
	if (!currentAnimation) return;
	var animInfo = getAnimByName(currentAnimation);
	animInfo.frameCount = count;
	getAnimation(currentAnimation);
}

function getAnimByName(name) {
	for (var i in animations)
		if (animations[i].name == name) return animations[i];
}

function addKeyframe() {
	if (!currentFrame) { alert("Select a keyframe first."); return; }
	if (!currentBone) { alert("Select a bone first."); return; }
	var anim = currentBone.getAnimationByName($(currentFrame).attr("anim"));
	if (!anim) anim = currentBone.addAnimation($(currentFrame).attr("anim"));
	var keyframe = new Keyframe($(currentFrame).attr("time") * 1, $("#cb_x").val() * 1, $("#cb_y").val() * 1, $("#cb_l").val() * 1, $("#cb_a").val() * 1);
	anim.addKeyframe(keyframe);
}

function startAnimation() {
	cFrame = 0;
	timer = setInterval("tickAnimation()", 33.33);
}

function tickAnimation() {
	getKeyframe(currentAnimation, cFrame);
	$("#div_keyframes").scrollLeft(27 * cFrame);
	cFrame ++;
	if (cFrame > getAnimByName(currentAnimation).frameCount - 1) {
		$("#div_frameInfo_" + (cFrame - 1)).css("background-color", "white");
		cFrame = 0;
	}
}

function stopAnimation() {
	clearInterval(timer);
	for (var i = 0; i < getAnimByName(currentAnimation).frameCount; i ++) {
		$("#div_frameInfo_" + i).css("background-color", "white");
	}
	if (currentFrame) selectKeyframe(currentFrame);
}